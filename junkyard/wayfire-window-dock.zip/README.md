# wayfire-window-dock (archived)

Uncommitted WIP plugin, removed at the author's request. Drag a window to a
screen edge to dock it; `slot_t` tracked docked / dragging / restoring views and
animated them with a `view_2d_transformer_t`.

- `src/window-dock.cpp` (463 lines), `metadata/wayfire-window-dock.xml`, `meson.build`.
- It was wired into the root build as the `with_window_dock` option
  (default true) plus a `subdir('wayfire-plugins/window-dock')` block; both were
  removed with it.
- Known issue never fixed: `fini()` cleared the `restoring` vector without
  `detach()`ing those slots, leaking a transformer on a live view if the plugin
  was unloaded mid-animation. The archived copy HAS that fix applied.
- `slot_t::restoring` (declared line 65, written line 272) was never read.
