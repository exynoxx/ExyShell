#include <wayfire/per-output-plugin.hpp>
#include <wayfire/plugin.hpp>
#include <wayfire/output.hpp>
#include <wayfire/core.hpp>
#include <wayfire/view.hpp>
#include <wayfire/toplevel-view.hpp>
#include <wayfire/view-transform.hpp>
#include <wayfire/compositor-view.hpp>
#include <wayfire/render-manager.hpp>
#include <wayfire/option-wrapper.hpp>
#include <wayfire/config/types.hpp>
#include <wayfire/signal-definitions.hpp>
#include <wayfire/workarea.hpp>
#include <wayfire/scene.hpp>

#include <memory>
#include <vector>
#include <algorithm>
#include <cmath>

namespace
{
constexpr const char *TRANSFORMER_NAME = "wayfire-window-dock";

// Exponential smoothing factor per frame for every slot position/scale.
// ponytail: one shared constant instead of a simple_animation_t per slot --
// slot targets change every frame during a drag, which a fixed-duration
// animation would have to re-target anyway. Swap to wf::animation if the
// easing curve ever matters.
constexpr float SMOOTH = 0.25f;
constexpr float SETTLED = 0.5f;
}

// ---------------------------------------------------------------------------
// Drag a window into the bottom `trigger_fraction` of the output and it shrinks
// toward the cursor; release it there and it stays, parked in a strip along the
// bottom edge. Docked windows are LIVE views held by a view_2d_transformer_t --
// no snapshots, no custom scene nodes: input is remapped with the rendering, so
// a docked window stays clickable and keeps painting.
//
// The strip chrome is a wf::color_rect_view_t on the BOTTOM layer and the space
// it occupies is reserved through the output's workarea manager, which is the
// same thing a layer-shell panel's exclusive zone buys.
// ---------------------------------------------------------------------------
class wayfire_window_dock_t : public wf::per_output_plugin_instance_t
{
    wf::option_wrapper_t<int> slot_width_opt{"wayfire-window-dock/slot_width"};
    wf::option_wrapper_t<int> strip_height_opt{"wayfire-window-dock/strip_height"};
    wf::option_wrapper_t<int> gap_opt{"wayfire-window-dock/gap"};
    wf::option_wrapper_t<int> slot_padding_opt{"wayfire-window-dock/slot_padding"};
    wf::option_wrapper_t<double> trigger_fraction_opt{"wayfire-window-dock/trigger_fraction"};
    wf::option_wrapper_t<wf::color_t> strip_color_opt{"wayfire-window-dock/strip_color"};

    // A view under our control: either docked, being dragged toward the dock,
    // or on its way back to identity after a release outside the strip.
    struct slot_t
    {
        wayfire_toplevel_view view;
        std::shared_ptr<wf::scene::view_2d_transformer_t> tr;
        wf::signal::connection_t<wf::view_unmapped_signal> on_unmap;

        // Smoothed toward the targets below every frame.
        float scale = 1.0f, x = 0.0f, y = 0.0f;
        float tgt_scale = 1.0f, tgt_x = 0.0f, tgt_y = 0.0f;
        bool restoring = false;
    };

    std::vector<std::unique_ptr<slot_t>> docked;
    std::unique_ptr<slot_t> dragging;
    std::vector<std::unique_ptr<slot_t>> restoring;
    int insert_index = 0;
    double drag_progress = 0.0;

    std::shared_ptr<wf::color_rect_view_t> strip;
    wf::output_workarea_manager_t::anchored_area reserved = {
        .edge = wf::output_workarea_manager_t::ANCHORED_EDGE_BOTTOM,
        .reserved_size = 0,
        .reflowed = nullptr,
    };
    bool area_reserved = false;
    bool hook_active = false;

    wf::signal::connection_t<wf::view_move_request_signal> on_move_request =
        [this] (wf::view_move_request_signal *ev)
    {
        if (ev->view && ev->view->is_mapped())
        {
            begin_drag(ev->view);
        }
    };

    wf::effect_hook_t on_frame = [this] () { tick(); };

  public:
    void init() override
    {
        output->connect(&on_move_request);
    }

    void fini() override
    {
        on_move_request.disconnect();
        for (auto& s : docked)
        {
            detach(*s);
        }
        docked.clear();
        // Slots mid-restore still own a transformer on a live view; clearing
        // the vector alone would leak it if the plugin is unloaded mid-animation.
        for (auto& s : restoring)
        {
            detach(*s);
        }
        restoring.clear();
        if (dragging)
        {
            detach(*dragging);
            dragging.reset();
        }
        set_hook(false);
        sync_chrome();
    }

  private:
    // ---- geometry ---------------------------------------------------------

    wf::geometry_t strip_rect() const
    {
        auto og = output->get_relative_geometry();
        const int h = std::max(1, (int)strip_height_opt);
        return {og.x, og.y + og.height - h, og.width, h};
    }

    // Slot pitch, shrinking below slot_width once `count` slots no longer fit.
    // This is the whole overflow story: windows get smaller instead of the
    // strip scrolling.
    // ponytail: squeeze-to-fit rather than a scrollable strip. Add scrolling if
    // docking a dozen windows ever becomes a real workflow.
    float slot_size(int count) const
    {
        const int pad = slot_padding_opt, gap = gap_opt;
        const float avail = strip_rect().width - 2.0f * pad;
        if (count <= 0)
        {
            return slot_width_opt;
        }
        return std::min<float>(slot_width_opt, (avail - (count - 1) * gap) / count);
    }

    // Centre of slot `index` when the strip holds `count` slots.
    wf::pointf_t slot_centre(int index, int count) const
    {
        auto sr = strip_rect();
        const float size = slot_size(count);
        const float pitch = size + gap_opt;
        const float content = count * pitch - gap_opt;
        const float start = sr.x + (sr.width - content) / 2.0f;
        return {start + index * pitch + size / 2.0f, sr.y + sr.height / 2.0f};
    }

    // Uniform scale that fits the view into one slot, both axes.
    float fitted_scale(wayfire_toplevel_view view, int count) const
    {
        auto g = view->get_geometry();
        if ((g.width <= 0) || (g.height <= 0))
        {
            return 1.0f;
        }
        const float inner_h = strip_rect().height - 2.0f * slot_padding_opt;
        return std::min(slot_size(count) / g.width, std::max(1.0f, inner_h) / g.height);
    }

    // ---- slot bookkeeping -------------------------------------------------

    std::unique_ptr<slot_t> make_slot(wayfire_toplevel_view view)
    {
        auto s = std::make_unique<slot_t>();
        s->view = view;
        s->tr = std::make_shared<wf::scene::view_2d_transformer_t>(view);
        view->get_transformed_node()->add_transformer(
            s->tr, wf::TRANSFORMER_2D, TRANSFORMER_NAME);

        wayfire_toplevel_view captured = view;
        s->on_unmap = [this, captured] (wf::view_unmapped_signal*)
        {
            forget(captured);
        };
        view->connect(&s->on_unmap);
        return s;
    }

    void detach(slot_t& s)
    {
        if (s.tr && s.view)
        {
            s.view->get_transformed_node()->rem_transformer(s.tr);
        }
        s.on_unmap.disconnect();
        s.tr.reset();
    }

    // Pull a view out of whichever list holds it, WITHOUT touching the
    // transformer -- used both when the view dies and when a docked window is
    // grabbed for an undock drag.
    std::unique_ptr<slot_t> take(wayfire_toplevel_view view)
    {
        auto it = std::find_if(docked.begin(), docked.end(),
            [&] (auto& s) { return s->view == view; });
        if (it != docked.end())
        {
            auto s = std::move(*it);
            docked.erase(it);
            return s;
        }
        return nullptr;
    }

    void forget(wayfire_toplevel_view view)
    {
        if (auto s = take(view))
        {
            detach(*s);
        }
        if (dragging && (dragging->view == view))
        {
            detach(*dragging);
            dragging.reset();
        }
        restoring.erase(std::remove_if(restoring.begin(), restoring.end(),
            [&] (auto& s)
        {
            if (s->view != view)
            {
                return false;
            }
            detach(*s);
            return true;
        }), restoring.end());
        sync_chrome();
    }

    // ---- drag -------------------------------------------------------------

    void begin_drag(wayfire_toplevel_view view)
    {
        if (dragging)
        {
            // A second move request while one is live: let the old one settle.
            release_drag();
        }

        // Grabbing a docked window undocks it -- keep its transformer so the
        // grow-back is continuous instead of a snap to full size.
        dragging = take(view);
        if (!dragging)
        {
            dragging = make_slot(view);
        }

        insert_index = (int)docked.size();
        drag_progress = 0.0;
        set_hook(true);
    }

    void release_drag()
    {
        if (!dragging)
        {
            return;
        }

        if (drag_progress >= 1.0)
        {
            insert_index = std::clamp(insert_index, 0, (int)docked.size());
            docked.insert(docked.begin() + insert_index, std::move(dragging));
        } else
        {
            dragging->restoring = true;
            dragging->tgt_scale = 1.0f;
            dragging->tgt_x = dragging->tgt_y = 0.0f;
            restoring.push_back(std::move(dragging));
        }

        dragging.reset();
        drag_progress = 0.0;
        sync_chrome();
    }

    // ---- per-frame --------------------------------------------------------

    void tick()
    {
        if (dragging && !output->is_plugin_active("move"))
        {
            release_drag();
        }

        const int count = (int)docked.size() + (dragging && (drag_progress > 0.0) ? 1 : 0);

        if (dragging)
        {
            auto cursor = output->get_cursor_position();
            auto og = output->get_relative_geometry();
            const double y_trigger = og.y + og.height * (double)trigger_fraction_opt;
            const double span = std::max(1.0, (og.y + og.height) - y_trigger);
            drag_progress = std::clamp((cursor.y - y_trigger) / span, 0.0, 1.0);

            const float target = fitted_scale(dragging->view, std::max(1, count));
            dragging->tgt_scale = 1.0f + (float)drag_progress * (target - 1.0f);

            // Shrink toward the pointer: view_2d scales about the view's centre,
            // so hold the cursor's offset from that centre fixed.
            auto g = dragging->view->get_geometry();
            const float cx = g.x + g.width / 2.0f, cy = g.y + g.height / 2.0f;
            dragging->tgt_x = (1.0f - dragging->tgt_scale) * (float)(cursor.x - cx);
            dragging->tgt_y = (1.0f - dragging->tgt_scale) * (float)(cursor.y - cy);

            // The gap opens where the cursor is: count the docked slots whose
            // centre sits left of it. Midpoint crossing gives hysteresis free.
            insert_index = 0;
            for (int i = 0; i < (int)docked.size(); i++)
            {
                if (slot_centre(i, count).x < cursor.x)
                {
                    insert_index = i + 1;
                }
            }
        }

        // Docked windows lay out around the open gap.
        for (int i = 0; i < (int)docked.size(); i++)
        {
            auto& s = *docked[i];
            const int visual = (dragging && (drag_progress > 0.0) && (i >= insert_index)) ? i + 1 : i;
            auto c = slot_centre(visual, std::max(1, count));
            auto g = s.view->get_geometry();
            s.tgt_scale = fitted_scale(s.view, std::max(1, count));
            s.tgt_x = (float)(c.x - (g.x + g.width / 2.0));
            s.tgt_y = (float)(c.y - (g.y + g.height / 2.0));
        }

        bool busy = dragging != nullptr;
        for (auto& s : docked)
        {
            busy |= smooth(*s);
        }
        if (dragging)
        {
            smooth(*dragging);
        }

        restoring.erase(std::remove_if(restoring.begin(), restoring.end(),
            [&] (auto& s)
        {
            if (smooth(*s))
            {
                busy = true;
                return false;
            }
            detach(*s);
            return true;
        }), restoring.end());

        sync_chrome();
        output->render->damage_whole();

        if (!busy)
        {
            set_hook(false);
        }
    }

    // Ease one slot toward its target; returns true while still moving.
    bool smooth(slot_t& s)
    {
        if (!s.tr || !s.view)
        {
            return false;
        }

        s.scale += (s.tgt_scale - s.scale) * SMOOTH;
        s.x += (s.tgt_x - s.x) * SMOOTH;
        s.y += (s.tgt_y - s.y) * SMOOTH;

        auto g = s.view->get_geometry();
        const bool moving =
            (std::fabs(s.tgt_x - s.x) > SETTLED) ||
            (std::fabs(s.tgt_y - s.y) > SETTLED) ||
            (std::fabs(s.tgt_scale - s.scale) * std::max(g.width, g.height) > SETTLED);

        if (!moving)
        {
            s.scale = s.tgt_scale;
            s.x = s.tgt_x;
            s.y = s.tgt_y;
        }

        auto n = s.view->get_transformed_node();
        n->begin_transform_update();
        s.tr->scale_x = s.tr->scale_y = s.scale;
        s.tr->translation_x = s.x;
        s.tr->translation_y = s.y;
        n->end_transform_update();
        return moving;
    }

    void set_hook(bool on)
    {
        if (on == hook_active)
        {
            return;
        }
        hook_active = on;
        if (on)
        {
            output->render->add_effect(&on_frame, wf::OUTPUT_EFFECT_PRE);
        } else
        {
            output->render->rem_effect(&on_frame);
        }
    }

    // ---- strip chrome -----------------------------------------------------

    // Strip is visible whenever something is docked or a drag has entered the
    // zone; the workarea is only reserved for a settled dock, so an aborted
    // drag never resizes the user's windows.
    void sync_chrome()
    {
        const bool want_strip = !docked.empty() || (dragging && (drag_progress > 0.0));
        const bool want_area = !docked.empty();

        if (want_strip && !strip)
        {
            strip = wf::color_rect_view_t::create(
                wf::VIEW_ROLE_DESKTOP_ENVIRONMENT, output, wf::scene::layer::BOTTOM);
            strip->set_border(0);
        }

        if (strip)
        {
            if (!want_strip)
            {
                strip->close();
                strip.reset();
            } else
            {
                strip->set_color(strip_color_opt);
                strip->set_geometry(strip_rect());
            }
        }

        if (want_area != area_reserved)
        {
            reserved.reserved_size = strip_rect().height;
            if (want_area)
            {
                output->workarea->add_reserved_area(&reserved);
            } else
            {
                output->workarea->remove_reserved_area(&reserved);
            }
            area_reserved = want_area;
            output->workarea->reflow_reserved_areas();
        }
    }
};

DECLARE_WAYFIRE_PLUGIN(wf::per_output_plugin_t<wayfire_window_dock_t>)
