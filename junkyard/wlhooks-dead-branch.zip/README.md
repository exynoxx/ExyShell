# wlhooks dead branch (archived)

Removed from `wlhooks/` because it was unreachable. Every live entry point
(`wlhooks_init_toplevel_with_display`, `wlhooks_idle_notify_init`, the
`wlhooks_output_mgmt_*` family) set `minimal_mode = true`, which gated off every
one of these files. The only non-minimal entry, `wlhooks_init()`, had no caller
outside the old `junkyard/lumen-panel`.

Contents:

- `egl.c/.h`, `protocols/{compositor,layershell}.*` — the legacy EGL +
  layer-shell rendering path. Superseded by GTK4 + gtk4-layer-shell.
- `protocols/{pointer,keyboard,xkb}.*` — input listeners. GTK owns input now;
  these only ran under `if (!minimal_mode)`.
- `protocols/{shm,screencopy}.*` + `generated/wlr-screencopy-unstable.*` — the
  wlr-screencopy desktop-snapshot path for the lockscreen backdrop. Replaced by
  `BlurredWallpaper` (it shared GDK's Wayland display and crashed on lock).
- `protocols/activation.*` + `generated/xdg-activation-v1-*` — xdg-activation.
  Bound at init but no caller ever requested a token.
- `generated/xdg-shell-client-protocol.*` — compiled but never `#include`d
  anywhere.
- `_modified-originals/` — pre-trim copies of the five files that were edited
  rather than deleted (`main.c`, `wlhooks.h`, `meson.build`, `protocols/seat.*`).

Also dropped with this branch: the `wayland-egl`, `egl`, `glesv2` and
`xkbcommon` pkg-config dependencies, which `wlhooks_dep` propagated to all
seven consuming binaries.
