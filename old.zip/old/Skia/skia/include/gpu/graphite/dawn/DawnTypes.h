/*
 * Copyright 2022 Google LLC
 *
 * Use of this source code is governed by a BSD-style license that can be
 * found in the LICENSE file.
 */

// DEPRECRATED: DawnTypes.h will be removed in the future, please include DawnGraphiteTypes.h
#include "include/gpu/graphite/dawn/DawnGraphiteTypes.h"
