/*
 * Copyright 2022 Google LLC
 *
 * Use of this source code is governed by a BSD-style license that can be
 * found in the LICENSE file.
 */

// DEPRECRATED: MtlGraphiteUtils.h will be removed in the future, please include MtlBackendContext.h
#include "include/gpu/graphite/mtl/MtlBackendContext.h"
