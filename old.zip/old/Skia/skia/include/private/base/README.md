Files in "base" are used by many parts of Skia, but are not part of the public Skia API.
See also src/base for other files that are part of base, but not needed by the public API.

Files here should not depend on anything other than system headers or other files in base.